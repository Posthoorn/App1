
package com.nando.me.deposthoornnew;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ActivityBestellen extends AppCompatActivity {

    Button btnTerug, btnInloggen, btnRegistreren;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bestellen);

        btnTerug = (Button) findViewById(R.id.btnTerug);
        btnInloggen = (Button) findViewById(R.id.btnTerug);
        btnRegistreren = (Button) findViewById(R.id.btnTerug);

        btnTerug.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Terug = new Intent(ActivityBestellen.this, MainActivity.class);
                startActivity(Terug);
            }
        });

        btnInloggen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Inloggen = new Intent(ActivityBestellen.this, MainActivity.class);
                startActivity(Inloggen);
            }
        });

        btnRegistreren.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Registreren = new Intent(ActivityBestellen.this, MainActivity.class);
                startActivity(Registreren);
            }
        });
    }
}
